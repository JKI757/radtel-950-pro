V0.18
1. Fix full channel mode channel number input bug
2. Radio AM mode increases by 5K steps
3.Fixed bug where shortwave receiver did not switch to FM radio signal
